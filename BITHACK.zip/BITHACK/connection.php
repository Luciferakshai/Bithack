<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "infoportal";

$conn = new mysqli($servername, $username, $password, $dbname);
?>